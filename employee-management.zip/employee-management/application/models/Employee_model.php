<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Employee_model extends CI_Model {

    public function __construct() {
        parent::__construct();
        $this->load->database();
    }

    // Get all employees
    public function get_all_employees() {
        $query = $this->db->get('emp_details');
        return $query->result();
    }

    // Get employee by ID
    public function get_employee($id) {
        $this->db->where('id', $id);
        $query = $this->db->get('emp_details');
        return $query->row();
    }

    // Insert new employee
    public function insert_employee($data) {
        return $this->db->insert('emp_details', $data);
    }

    // Update employee
    public function update_employee($id, $data) {
        $this->db->where('id', $id);
        return $this->db->update('emp_details', $data);
    }

    // Delete employee
    public function delete_employee($id) {
        $this->db->where('id', $id);
        return $this->db->delete('emp_details');
    }
}