<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User_model extends CI_Model {

    public function __construct() {
        parent::__construct();
        $this->load->database();
    }

    // Check login credentials
    public function check_login($username, $password) {
        $this->db->where('user_name', $username);
        $query = $this->db->get('login_details');
        
        if ($query->num_rows() > 0) {
            $user = $query->row();
            if (password_verify($password, $user->password)) {
                return $user;
            }
        }
        return false;
    }

    // Get user by ID
    public function get_user($id) {
        $this->db->where('id', $id);
        $query = $this->db->get('login_details');
        return $query->row();
    }
}