<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth extends CI_Controller {
    
    public function __construct() {
        parent::__construct();
        $this->load->model('user_model');
        $this->load->helper('url');
        $this->load->library('session');
        $this->load->library('form_validation');
    }
    
    public function index() {
        // If already logged in, redirect to dashboard
        if ($this->session->userdata('logged_in')) {
            redirect('employee');
        }
        
        $this->load->view('login_view');
    }
    
    public function login() {
      
        $this->form_validation->set_rules('username', 'Username', 'required');
        $this->form_validation->set_rules('password', 'Password', 'required');
        // echo $password.'djsalkdjlksadjlksadksanhd';

        if ($this->form_validation->run() == FALSE) {
            $this->load->view('login_view');
        } else {
            $username = $this->input->post('username');
            $password = $this->input->post('password');
            $user = $this->user_model->check_login($username, $password);
            
            if ($user) {
                $session_data = array(
                    'user_id' => $user->id,
                    'username' => $user->user_name,
                    'name' => $user->name,
                    'logged_in' => TRUE
                );
                
                $this->session->set_userdata($session_data);
                redirect('employee');
            } else {
                $this->session->set_flashdata('error', 'Invalid username or password');
                redirect('auth');
            }
        }
    }

    public function logout() {
        echo 'logout';
        $this->session->sess_destroy();
        redirect('auth');
    }
}