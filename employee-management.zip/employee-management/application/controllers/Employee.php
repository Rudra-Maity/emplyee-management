<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Employee extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('employee_model');
        $this->load->helper('url');
        $this->load->library('session');
        $this->load->library('form_validation');
        
        // Check if user is logged in
        if (!$this->session->userdata('logged_in')) {
            redirect('auth');
        }
    }

    public function index() {
        $data['employees'] = $this->employee_model->get_all_employees();
        $data['title'] = 'Employee List';
        
        $this->load->view('templates/header', $data);
        $this->load->view('employee_list', $data);
        $this->load->view('templates/footer');
    }

    public function add() {
        $data['title'] = 'Add New Employee';
        
        $this->form_validation->set_rules('name', 'Name', 'required');
        $this->form_validation->set_rules('address', 'Address', 'required');
        $this->form_validation->set_rules('designation', 'Designation', 'required');
        $this->form_validation->set_rules('salary', 'Salary', 'required|numeric');
        
        if ($this->form_validation->run() === FALSE) {
            $this->load->view('templates/header', $data);
            $this->load->view('employee_add', $data);
            $this->load->view('templates/footer');
        } else {
            // Handle file upload
            $config['upload_path'] = './uploads/';
            print_r($config['upload_path']);
            $config['allowed_types'] = 'gif|jpg|jpeg|png';
            $config['max_size'] = 2048;
            $config['encrypt_name'] = TRUE;
            
            $this->load->library('upload', $config);
            
            if (!$this->upload->do_upload('picture')) {
                $error = $this->upload->display_errors();
                $this->session->set_flashdata('error', $error);
                
                $this->load->view('templates/header', $data);
                $this->load->view('employee_add', $data);
                $this->load->view('templates/footer');
            } else {
                $upload_data = $this->upload->data();
                $picture_path = 'uploads/' . $upload_data['file_name'];
                
                $employee_data = array(
                    'name' => $this->input->post('name'),
                    'address' => $this->input->post('address'),
                    'designation' => $this->input->post('designation'),
                    'salary' => $this->input->post('salary'),
                    'picture' => $picture_path
                );
                
                $this->employee_model->insert_employee($employee_data);
                $this->session->set_flashdata('success', 'Employee added successfully');
                redirect('employee');
            }
        }
    }

    public function edit($id = NULL) {
        if ($id === NULL) {
            show_404();
        }
        
        $data['employee'] = $this->employee_model->get_employee($id);
        
        if (empty($data['employee'])) {
            show_404();
        }
        
        $data['title'] = 'Edit Employee';
        
        $this->form_validation->set_rules('name', 'Name', 'required');
        $this->form_validation->set_rules('address', 'Address', 'required');
        $this->form_validation->set_rules('designation', 'Designation', 'required');
        $this->form_validation->set_rules('salary', 'Salary', 'required|numeric');
        
        if ($this->form_validation->run() === FALSE) {
            $this->load->view('templates/header', $data);
            $this->load->view('employee_edit', $data);
            $this->load->view('templates/footer');
        } else {
            $employee_data = array(
                'name' => $this->input->post('name'),
                'address' => $this->input->post('address'),
                'designation' => $this->input->post('designation'),
                'salary' => $this->input->post('salary')
            );
            
            // Check if new picture is uploaded
            if ($_FILES['picture']['name']) {
                $config['upload_path'] = './uploads/';
                $config['allowed_types'] = 'gif|jpg|jpeg|png';
                $config['max_size'] = 2048;
                $config['encrypt_name'] = TRUE;
                
                $this->load->library('upload', $config);
                
                if (!$this->upload->do_upload('picture')) {
                    $error = $this->upload->display_errors();
                    $this->session->set_flashdata('error', $error);
                    
                    $this->load->view('templates/header', $data);
                    $this->load->view('employee_edit', $data);
                    $this->load->view('templates/footer');
                    return;
                } else {
                    $upload_data = $this->upload->data();
                    $employee_data['picture'] = 'uploads/' . $upload_data['file_name'];
                    
                    // Remove old picture if exists
                    if ($data['employee']->picture && file_exists($data['employee']->picture)) {
                        unlink($data['employee']->picture);
                    }
                }
            }
            
            $this->employee_model->update_employee($id, $employee_data);
            $this->session->set_flashdata('success', 'Employee updated successfully');
            redirect('employee');
        }
    }

    public function delete($id = NULL) {
        if ($id === NULL) {
            show_404();
        }
        
        $employee = $this->employee_model->get_employee($id);
        
        if (empty($employee)) {
            show_404();
        }
        
        // Remove picture file
        if ($employee->picture && file_exists($employee->picture)) {
            unlink($employee->picture);
        }
        
        $this->employee_model->delete_employee($id);
        $this->session->set_flashdata('success', 'Employee deleted successfully');
        redirect('employee');
    }
}