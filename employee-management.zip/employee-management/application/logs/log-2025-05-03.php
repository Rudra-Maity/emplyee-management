<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-05-03 13:09:41 --> Severity: Warning --> Undefined array key "subclass_prefix" C:\xampp\htdocs\employee-management\system\core\CodeIgniter.php 373
ERROR - 2025-05-03 13:09:41 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user ''@'localhost' (using password: NO) C:\xampp\htdocs\employee-management\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2025-05-03 13:09:41 --> Unable to connect to the database
ERROR - 2025-05-03 13:09:42 --> Severity: Warning --> Undefined array key "subclass_prefix" C:\xampp\htdocs\employee-management\system\core\CodeIgniter.php 373
ERROR - 2025-05-03 13:09:42 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user ''@'localhost' (using password: NO) C:\xampp\htdocs\employee-management\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2025-05-03 13:09:42 --> Unable to connect to the database
ERROR - 2025-05-03 13:12:08 --> Severity: Warning --> Undefined array key "subclass_prefix" C:\xampp\htdocs\employee-management\system\core\CodeIgniter.php 373
ERROR - 2025-05-03 13:12:29 --> Severity: Warning --> Undefined array key "subclass_prefix" C:\xampp\htdocs\employee-management\system\core\CodeIgniter.php 373
ERROR - 2025-05-03 13:56:38 --> Severity: Warning --> Undefined array key "subclass_prefix" C:\xampp\htdocs\employee-management\system\core\CodeIgniter.php 373
ERROR - 2025-05-03 13:56:39 --> Severity: Warning --> Undefined array key "subclass_prefix" C:\xampp\htdocs\employee-management\system\core\CodeIgniter.php 373
ERROR - 2025-05-03 13:56:39 --> Severity: Warning --> Undefined array key "subclass_prefix" C:\xampp\htdocs\employee-management\system\core\CodeIgniter.php 373
