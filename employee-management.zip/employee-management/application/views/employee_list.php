<div class="row">
    <div class="col-md-12">
        <h2 class="page-header animate__animated animate__fadeInDown">
            <i class="fas fa-users me-2"></i>Employee List
        </h2>
    </div>
</div>

<div class="row mb-4">
    <div class="col-md-8">
        <a href="<?php echo base_url('employee/add'); ?>" class="btn btn-primary animate__animated animate__fadeInLeft">
            <i class="fas fa-user-plus me-2"></i>Add New Employee
        </a>
    </div>
    <div class="col-md-4">
        <div class="input-group animate__animated animate__fadeInRight">
            <input type="text" id="search-input" class="form-control" placeholder="Search employee...">
            <button class="btn btn-outline-secondary" type="button">
                <i class="fas fa-search"></i>
            </button>
        </div>
    </div>
</div>

<?php if (empty($employees)) : ?>
<div class="alert alert-info animate__animated animate__fadeIn" role="alert">
    <i class="fas fa-info-circle me-2"></i>No employees found. Click "Add New Employee" to add your first employee.
</div>
<?php else : ?>
<div class="row">
    <?php foreach ($employees as $employee) : ?>
    <div class="col-md-4 mb-4">
        <div class="card employee-card animate-new">
            <div class="card-body text-center">
                <img src="<?php echo str_replace('index.php/', '', base_url()).($employee->picture); ?>" class="employee-image mb-3" alt="<?php echo $employee->name; ?>">
                <h5 class="card-title"><?php echo $employee->name; ?></h5>
                <p class="badge bg-primary"><?php echo $employee->designation; ?></p>
                <div class="card-text">
                    <p><i class="fas fa-map-marker-alt me-2"></i><?php echo $employee->address; ?></p>
                    <p><i class="fas fa-dollar-sign me-2"></i><?php echo number_format($employee->salary, 2); ?></p>
                </div>
                <hr>
                <div class="btn-group w-100">
                    <a href="<?php echo base_url('employee/edit/'.$employee->id); ?>" class="btn btn-sm btn-warning">
                        <i class="fas fa-edit me-1"></i>Edit
                    </a>
                    <a href="<?php echo base_url('employee/delete/'.$employee->id); ?>" class="btn btn-sm btn-danger" 
                       onclick="return confirm('Are you sure you want to delete this employee?')">
                        <i class="fas fa-trash-alt me-1"></i>Delete
                    </a>
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; ?>
</div>
<?php endif; ?>

<script>
    // Search functionality
    $(document).ready(function() {
        $("#search-input").on("keyup", function() {
            var value = $(this).val().toLowerCase();
            $(".employee-card").filter(function() {
                $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1);
            });
        });
    });
</script>