<div class="row">
    <div class="col-md-12">
        <h2 class="page-header animate__animated animate__fadeInDown">
            <i class="fas fa-user-edit me-2"></i>Edit Employee
        </h2>
    </div>
</div>

<div class="row">
    <div class="col-md-12">
        <div class="card animate__animated animate__fadeIn">
            <div class="card-body">
                <?php echo form_open_multipart('employee/edit/'.$employee->id, ['id' => 'edit-employee-form']); ?>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="name" class="form-label">Full Name <span class="text-danger">*</span></label>
                                <div class="input-group">
                                    <span class="input-group-text"><i class="fas fa-user"></i></span>
                                    <input type="text" class="form-control" id="name" name="name" value="<?php echo $employee->name; ?>" required>
                                </div>
                            </div>
                            
                            <div class="mb-3">
                                <label for="address" class="form-label">Address <span class="text-danger">*</span></label>
                                <div class="input-group">
                                    <span class="input-group-text"><i class="fas fa-map-marker-alt"></i></span>
                                    <textarea class="form-control" id="address" name="address" rows="3" required><?php echo $employee->address; ?></textarea>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="designation" class="form-label">Designation <span class="text-danger">*</span></label>
                                <div class="input-group">
                                    <span class="input-group-text"><i class="fas fa-briefcase"></i></span>
                                    <input type="text" class="form-control" id="designation" name="designation" value="<?php echo $employee->designation; ?>" required>
                                </div>
                            </div>
                            
                            <div class="mb-3">
                                <label for="salary" class="form-label">Salary <span class="text-danger">*</span></label>
                                <div class="input-group">
                                    <span class="input-group-text"><i class="fas fa-dollar-sign"></i></span>
                                    <input type="number" step="0.01" class="form-control" id="salary" name="salary" value="<?php echo $employee->salary; ?>" required>
                                </div>
                            </div>
                            
                            <div class="mb-3">
                                <label for="picture" class="form-label">Profile Picture</label>
                                <div class="input-group">
                                    <span class="input-group-text"><i class="fas fa-image"></i></span>
                                    <input type="file" class="form-control" id="picture" name="picture" accept="image/*">
                                </div>
                                <div class="form-text">Leave empty to keep current picture. (Max size: 2MB, Allowed formats: JPG, JPEG, PNG, GIF)</div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="row mt-3">
                        <div class="col-md-12">
                            <div class="mb-3">
                                <div id="current-image" class="text-center p-3 border rounded mb-3">
                                    <h6 class="mb-2">Current Profile Picture</h6>
                                    <img src="<?php echo str_replace('index.php/', '', base_url()).($employee->picture); ?>" class="img-fluid" style="max-height: 200px;">
                                </div>
                                <div id="image-preview" class="text-center p-3 border rounded d-none mb-3">
                                    <h6 class="mb-2">New Profile Picture</h6>
                                    <img src="" id="preview-img" class="img-fluid" style="max-height: 200px;">
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="row mt-3">
                        <div class="col-md-12 text-end">
                            <a href="<?php echo base_url('employee'); ?>" class="btn btn-secondary me-2">
                                <i class="fas fa-arrow-left me-1"></i>Cancel
                            </a>
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-save me-1"></i>Update Employee
                            </button>
                        </div>
                    </div>
                <?php echo form_close(); ?>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {
        // Preview image before upload
        $("#picture").change(function() {
            if (this.files && this.files[0]) {
                var reader = new FileReader();
                reader.onload = function(e) {
                    $("#preview-img").attr("src", e.target.result);
                    $("#image-preview").removeClass("d-none").addClass("animate__animated animate__fadeIn");
                }
                reader.readAsDataURL(this.files[0]);
            }
        });
        
        // Form submission animation
        $("#edit-employee-form").submit(function() {
            $("button[type='submit']").html('<i class="fas fa-spinner fa-spin me-1"></i>Updating...').attr("disabled", true);
        });
    });
</script>