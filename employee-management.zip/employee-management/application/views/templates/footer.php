</div> <!-- End .container from header -->

    <footer class="mt-5 py-3 bg-dark text-white">
        <div class="container text-center">
            <p class="mb-0">Employee Management System &copy; <?php echo date('Y'); ?></p>
        </div>
    </footer>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    
    <script>
        // Add animation classes to elements
        $(document).ready(function() {
            // Animate cards on page load
            $('.card').addClass('animate__animated animate__fadeIn');
            
            // Animate button hover
            $('.btn').hover(
                function() { $(this).addClass('animate__animated animate__pulse'); },
                function() { $(this).removeClass('animate__animated animate__pulse'); }
            );
            
            // Delay fadeout for flash messages
            setTimeout(function() {
                $('.alert').fadeOut('slow');
            }, 5000);
            
            // Add animation to tables
            $('tr').each(function(index) {
                $(this).addClass('animate__animated animate__fadeInUp');
                $(this).css('animation-delay', (index * 0.1) + 's');
            });
        });
    </script>
</body>
</html>