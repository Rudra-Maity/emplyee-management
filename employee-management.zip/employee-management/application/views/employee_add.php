<div class="row">
    <div class="col-md-12">
        <h2 class="page-header animate__animated animate__fadeInDown">
            <i class="fas fa-user-plus me-2"></i>Add New Employee
        </h2>
    </div>
</div>

<div class="row">
    <div class="col-md-12">
        <div class="card animate__animated animate__fadeIn">
            <div class="card-body">
                <?php echo form_open_multipart('employee/add', ['id' => 'add-employee-form']); ?>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="name" class="form-label">Full Name <span class="text-danger">*</span></label>
                                <div class="input-group">
                                    <span class="input-group-text"><i class="fas fa-user"></i></span>
                                    <input type="text" class="form-control" id="name" name="name" value="<?php echo set_value('name'); ?>" required>
                                </div>
                            </div>
                            
                            <div class="mb-3">
                                <label for="address" class="form-label">Address <span class="text-danger">*</span></label>
                                <div class="input-group">
                                    <span class="input-group-text"><i class="fas fa-map-marker-alt"></i></span>
                                    <textarea class="form-control" id="address" name="address" rows="3" required><?php echo set_value('address'); ?></textarea>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="designation" class="form-label">Designation <span class="text-danger">*</span></label>
                                <div class="input-group">
                                    <span class="input-group-text"><i class="fas fa-briefcase"></i></span>
                                    <input type="text" class="form-control" id="designation" name="designation" value="<?php echo set_value('designation'); ?>" required>
                                </div>
                            </div>
                            
                            <div class="mb-3">
                                <label for="salary" class="form-label">Salary <span class="text-danger">*</span></label>
                                <div class="input-group">
                                    <span class="input-group-text"><i class="fas fa-dollar-sign"></i></span>
                                    <input type="number" step="0.01" class="form-control" id="salary" name="salary" value="<?php echo set_value('salary'); ?>" required>
                                </div>
                            </div>
                            
                            <div class="mb-3">
                                <label for="picture" class="form-label">Profile Picture <span class="text-danger">*</span></label>
                                <div class="input-group">
                                    <span class="input-group-text"><i class="fas fa-image"></i></span>
                                    <input type="file" class="form-control" id="picture" name="picture" accept="image/*" required>
                                </div>
                                <div class="form-text">Upload a profile picture (Max size: 2MB, Allowed formats: JPG, JPEG, PNG, GIF)</div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="row mt-3">
                        <div class="col-md-12">
                            <div class="mb-3">
                                <div id="image-preview" class="text-center p-3 border rounded d-none mb-3">
                                    <img src="" id="preview-img" class="img-fluid" style="max-height: 200px;">
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="row mt-3">
                        <div class="col-md-12 text-end">
                            <a href="<?php echo base_url('employee'); ?>" class="btn btn-secondary me-2">
                                <i class="fas fa-arrow-left me-1"></i>Cancel
                            </a>
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-save me-1"></i>Save Employee
                            </button>
                        </div>
                    </div>
                <?php echo form_close(); ?>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {
        // Preview image before upload
        $("#picture").change(function() {
            if (this.files && this.files[0]) {
                var reader = new FileReader();
                reader.onload = function(e) {
                    $("#preview-img").attr("src", e.target.result);
                    $("#image-preview").removeClass("d-none").addClass("animate__animated animate__fadeIn");
                }
                reader.readAsDataURL(this.files[0]);
            }
        });
        
        // Form submission animation
        $("#add-employee-form").submit(function() {
            $("button[type='submit']").html('<i class="fas fa-spinner fa-spin me-1"></i>Saving...').attr("disabled", true);
        });
    });
</script>